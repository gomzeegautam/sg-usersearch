# customer-account
@ SpringBoot POC

Run the application locally 

 - git clone https://github.com/vbondoo7/customer-account.git
 
 - Import as maven project
 
 - Run mvn spring-boot:run
 
 - Visit http://localhost:8080
 
