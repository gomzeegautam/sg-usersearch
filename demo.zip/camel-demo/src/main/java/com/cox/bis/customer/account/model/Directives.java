package com.cox.bis.customer.account.model;

import java.util.List;

public class Directives {
	
	List<String> directives;

	public List<String> getDirectives() {
		return directives;
	}

	public void setDirectives(List<String> directives) {
		this.directives = directives;
	}
}
