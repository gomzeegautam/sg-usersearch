/**
 * 
 */
package com.camel.demo.route;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.cxf.CxfEndpoint;
import org.apache.camel.component.cxf.DataFormat;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;


@SpringBootApplication
@ComponentScan("com.camel.demo")
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class})
public class CustomerAccountRB extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(CustomerAccountRB.class, args);
	}

	@Bean
	ServletRegistrationBean servletRegistrationBean() {
		ServletRegistrationBean servlet = new ServletRegistrationBean(
				new CamelHttpTransportServlet(), "/customer/account/v1/*");
		servlet.setName("CamelServlet");
		return servlet;
	}

	@Component
	class CustomerCommentsRoute extends RouteBuilder {

		@Override
		public void configure() throws Exception {

			CamelContext camelContext = getContext();
			CxfEndpoint cxfEndpoint = new CxfEndpoint();
			cxfEndpoint.setAddress("http://localhost:8080/ws/");
			cxfEndpoint.setWsdlURL("countries.wsdl");
			cxfEndpoint.setCamelContext(camelContext);
			cxfEndpoint.setDataFormat(DataFormat.MESSAGE);
			cxfEndpoint.setDefaultBus(true);
			camelContext.addEndpoint("addressScrubServiceEndpoint", cxfEndpoint);


			from("timer:foo")
			.to("direct:test")
			.to("log:bar");

			from("direct:test")
			.routeId("account.get")
			.setHeader("operationName", constant("getCountry"))
			.process(exchange -> {
				exchange.getIn().setBody("<Envelope xmlns=\"http://schemas.xmlsoap.org/soap/envelope/\"><Body><getCountryRequest xmlns=\"http://soap.com/demo/service\"><name>Spain</name></getCountryRequest></Body></Envelope>");
			})
			.to("addressScrubServiceEndpoint")
			.process(exchange -> {
				System.out.println("Output is: " + exchange.getIn().getBody());
			})
			.log("Got Request for account-detail");

		}
	}
}